Submitted by: Hasan Ege (directory id: hege)  

Group Members: Hasan Ege (hege), Sadman Ishraq (sishraq), Tyler Do (tdo12348), Jinan Yousuf (jinan)

App Description: Allow users to research pokemon, store their top 5 pokemon and then retrieve previous data. It takes a while to load on render.com

**IMPORTANT** The render website initially will say error fetching Pokémon data. This is just because render.com is slow, so it may take a couple of minutes for it to fully load, but rest assured, the program is functional.  

YouTube Video Link: (https://youtu.be/irPYDq_7-ZA)

APIs: Pokedex (https://pokeapi.co/docs/v2) 

Contact Email:  hege@terpmail.umd.edu 

Deployed App Link: (https://pokedex335.onrender.com/) \
